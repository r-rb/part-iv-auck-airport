import numpy as np
import simplekml
import os
import math
from polycircles import polycircles

###################################################

### CONSTANTS

###################################################

# The coordinates of Auckland Airport
apt_lat = -37.013383 # degrees
apt_lon = 174.779962	# degrees

# The radius around the airport to enclose the runway
apt_rad = 4000 # metres

# Radius of the earth
earth_radius = 6.371e6 # metres

# Speed of a plane
speed = 13300.0

###################################################

### FUNCTIONS

###################################################

# Convert geospatial earth coordinates to cartesian rectangular coordinates
def earth2rect(lon, lat):
	theta = np.deg2rad(lat)
	phi = np.deg2rad(lon)
	R = earth_radius
	x = R*np.cos(theta)*np.cos(phi)
	y = R*np.cos(theta)*np.sin(phi)
	z = R*np.sin(theta)
	return np.array([x,y,z])

# Convert rectangular coordinates back to geospatial earth coordinates
def rect2earth(x,y,z):
	lat = np.rad2deg(math.asin(z/earth_radius))
	lon = np.rad2deg(math.atan2(y,x))
	return (lat, lon)

###################################################

### PLANE CLASS

###################################################

class Plane:
	def __init__(self, name, lat, lon):
		self.name = name
		self.lat = lat
		self.lon = lon

###################################################

### SET UP AIRPORT

###################################################

# Get Auckland airport's rectangular coordinate representation
apt_rect = earth2rect(apt_lon, apt_lat)

apt_circ = polycircles.Polycircle(latitude=apt_lat,
		                                longitude=apt_lon,
		                                radius=apt_rad,
		                                number_of_vertices=36)

###################################################

### FAKE DATA OF PLANES

###################################################

plane = []
plane.append(Plane("Rayner", -35.0, 170.0))
plane.append(Plane("Nathan", -39.0, 176.0))

###################################################

### SET UP KML

###################################################

# File
kml=simplekml.Kml()

pt = []
ls = []
for pl in plane:
	# Point trackers
	pt.append(kml.newpoint(name=pl.name,coords = [(pl.lon,pl.lat)]))
	ls.append(kml.newlinestring(name=pl.name+"path",coords = [(pl.lon,pl.lat)]))

# Airport
apt = kml.newpolygon(name="Auckland Airport", outerboundaryis=apt_circ.to_kml())
apt.style.polystyle.color = simplekml.Color.changealphaint(200, simplekml.Color.green)

###################################################

### SIMULATION

###################################################

for minute in range(0,3):
	id_arr = []

	for pl in plane:
		pl_rect = earth2rect(pl.lon,pl.lat)
		id_arr.append(np.linalg.norm(pl_rect-apt_rect)/speed)

	np.savetxt("./tmp/arrival_t.txt", id_arr, newline="\n")
	os.system("julia sim_solver.jl")
	schedules = np.loadtxt("./tmp/schedule.txt")

	# Update plane positions based on the schedule
	for idx,pl in enumerate(plane):
		pl_rect = earth2rect(pl.lon,pl.lat)
		if np.linalg.norm(apt_rect - pl_rect) >= schedules[idx]*speed:
			pl_rect += speed * (apt_rect - pl_rect)/np.linalg.norm(apt_rect - pl_rect)
			pl.lat,pl.lon = rect2earth(pl_rect[0],pl_rect[1],pl_rect[2])
			ls[idx].coords.addcoordinates([(pl.lon,pl.lat)])

		pt[idx].coords = [(pl.lon,pl.lat)]

# Create the file
kml.save('sim.kml');
os.system("gnome-maps sim.kml")	
		

